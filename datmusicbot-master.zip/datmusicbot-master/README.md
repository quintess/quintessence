# datmusic bot

https://telegram.me/datmusicbot

Simple telegram bot to download music from datmusic (https://github.com/alashow/music).
Currently just works with inline queries.
Caution! Bot implementation is a litte bit too simple :)

# Setup


1. Clone repository
2. Set bot token in `.env`
3. Run `main.py`